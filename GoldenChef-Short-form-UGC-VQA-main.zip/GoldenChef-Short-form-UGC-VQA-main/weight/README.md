The weight link is shown below.
**[https://pan.baidu.com/s/10e3FmJPCcjU1tuPLlO2OnQ?pwd=2nc8](https://pan.baidu.com/s/1mfLZhB9701v-gBFIxKdFPg?pwd=9m4f)**
__where “final_model.pth” refers to the weights of our final model, and “Pre_on_LSVQ_for_2.pth” represents the weights of our model after 2 epochs of training on the LSVQ dataset.__
