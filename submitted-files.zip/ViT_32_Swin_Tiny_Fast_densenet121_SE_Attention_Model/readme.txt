runtime per video [s] : 2.37
CPU[1] / GPU[0] : 1
Extra Data [1] / No Extra Data [0] : 1
Other description : Solution based on the SwinTransformer-Tiny , Vision Transformer (ViT) and DenseNet   models pre-trained on ImageNet and 3D-CNN. We have a python implementation, and report single core CPU runtime. We utilize additional datasets LSVQ for the training process.